package tp.pr3.mv;

/**
 * @author Javier Druet
 * @author Álvaro Asenjo
 * 
 */

// EN LA PRACTICA 3 NO SE UTILIZA ESTA CLASE.
public enum Orden {
	PUSH, POP, DUP, FLIP, LOAD, STORE, ADD, SUB, DIV, MUL, OUT, HALT
};
