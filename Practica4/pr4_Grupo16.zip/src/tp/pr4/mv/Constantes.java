package tp.pr4.mv;

/**
 * @author Javier Druet
 * @author Alvaro Asenjo
 * 
 */

public class Constantes {

	// DECLARACION DE CONSTANTES PARA TODA LA PRACTICA.
	public static String LINE_SEPARATOR = System.getProperty("line.separator");
	public static int DIMENSIONMEMORIA = 100;
	public static int DIMENSIONPILA = 10;
}
